package com.ssafy.travery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TraveryApplicationTests {

	@Test
	void contextLoads() {
	}

}
