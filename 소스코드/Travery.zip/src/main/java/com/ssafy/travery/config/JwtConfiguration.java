package com.ssafy.travery.config;

public class JwtConfiguration {

}
